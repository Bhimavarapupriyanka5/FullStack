import './App.css';
import { Routes, Route } from 'react-router-dom'
import Navbar from './Navbar';
import Footer from './Footer';
import Login from './Login';
import Dashboard from'./Dashboard';


function App() {
  return (
    <div className="App">
      <Navbar/>
      

      <Routes>
         
         <Route path='/Login' element={<Login/>}></Route> 
        <Route path='/Dashboard' element={<Dashboard/>}></Route>
          
      </Routes>
    
 <Footer/>



    </div>
    
  );
}

export default App;
